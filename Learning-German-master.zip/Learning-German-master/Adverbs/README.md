# Adverbs

### Words used
+ **auch** - too
+ **gern** - like to
+ **so** - so
+ **wirklich** - really

### PART 1

<table>
    <tr>
        <th>English</th>
        <th>German</th>
    </tr>
    <tr>
        <td>Hello, I am also Anna</td>
        <td>Hallo, ich bin auch Anna</td>
    </tr>
    <tr>
        <td>Really</td>
        <td>Wirklich</td>
    </tr>
    <tr>
        <td>Do you like to swim?</td>
        <td>Schwimmst du gern?</td>
    </tr>
    <tr>
        <td>I like to drink</td>
        <td>Ich trinke gerne</td>
    </tr>
    <tr>
        <td>You are so perfect</td>
        <td>Du bist so perfekt</td>
    </tr>
    <tr>
        <td>You are so strong</td>
        <td>Du bist so stark</td>
    </tr>
    <tr>
        <td>I like to eat</td>
        <td>Ich esse gerne</td>
    </tr>
    <tr>
        <td>Hot pizza is tasty, too</td>
        <td>Heiße Pizza ist auch lecker</td>
    </tr>
    <tr>
        <td>I too</td>
        <td>Ich auch</td>
    </tr>
    <tr>
        <td>No, not really</td>
        <td>Nein, nicht wirklich</td>
    </tr>
</table>
