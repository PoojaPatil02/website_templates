# Plurals

<table>
    <tr>
        <th>English</th>
        <th>German</th>
    </tr>
    <tr>
        <td>Cows are animals</td>
        <td>Kühe sind Tiere</td>
    </tr>
    <tr>
        <td>The horses</td>
        <td>Die Pferde</td>
    </tr>
    <tr>
        <td>The dogs</td>
        <td>Die Hunde</td>
    </tr>
    <tr>
        <td>The pigs</td>
        <td>Die Schweine</td>
    </tr>
    <tr>
        <td>The kids have fishes</td>
        <td>Die Kinder haben Fische</td>
    </tr>
    <tr>
        <td>He has horses</td>
        <td>Er hat Pferde</td>
    </tr>
    <tr>
        <td>We have pigs</td>
        <td>Wir haben Schweine</td>
    </tr>
    <tr>
        <td>I have dogs</td>
        <td>Ich habe Hunde</td>
    </tr>
    <tr>
        <td>The bears</td>
        <td>Die Bären</td>
    </tr>
    <tr>
        <td>The egg, the eggs</td>
        <td>Das Ei, die Eier</td>
    </tr>
    <tr>
        <td>The kid is eating insects</td>
        <td>Das Kind isst Insekten</td>
    </tr>
    <tr>
        <td>The humans</td>
        <td>Die Menschen</td>
    </tr>
    <tr>
        <td>We are eating potatoes</td>
        <td>Wir essen Kartoffeln</td>
    </tr>
    <tr>
        <td>We are reading newspapers</td>
        <td>Wir lesen Zeitungen</td>
    </tr>
    <tr>
        <td>Potatoes are good</td>
        <td>Kartoffeln sind gut</td>
    </tr>
    <tr>
        <td>The pigs are eating potatoes</td>
        <td>Die Schweine fressen Kartoffenln</td>
    </tr>
    <tr>
        <td>The ducks</td>
        <td>Die Enten</td>
    </tr>
    <tr>
        <td>the fies are drinking water</td>
        <td>Die Fliegen trinken Wasser</td>
    </tr>
    <tr>
        <td>I am having cats</td>
        <td>Ich habe Katzen</td>
    </tr>
    <tr>
        <td>Strawberries are tasty</td>
        <td>Erdbeeren sind lecker</td>
    </tr>
    <tr>
        <td>He eats oranges</td>
        <td>Er isst Orangen</td>
    </tr>
    <tr>
        <td>The spiders are drinking</td>
        <td>Die Spinnen trinken</td>
    </tr>
    <tr>
        <td>We are eating tomatoes</td>
        <td>Wir essen Tomaten</td>
    </tr>
    <tr>
        <td>The man is eating bananas</td>
        <td>Der Mann isst Bananen</td>
    </tr>
    <tr>
        <td>The cats are drinking milk</td>
        <td>Die Katzen trinken Milch</td>
    </tr>
    <tr>
        <td>The ducks</td>
        <td>Die Enten</td>
    </tr>
    <tr>
        <td>I have cats</td>
        <td>Ich habe Katzen</td>
    </tr>
    <tr>
        <td>He is eating oranges</td>
        <td>Er isst Orangen</td>
    </tr>
    <tr>
        <td>The birds</td>
        <td>Die Vögel</td>
    </tr>
    <tr>
        <td>The girls are drinking the milk</td>
        <td>Die Mädchen trinken die Milch</td>
    </tr>
    <tr>
        <td>I am eating apples</td>
        <td>Ich esse Äpfel</td>
    </tr>
    <tr>
        <td>The girls and the boys</td>
        <td>Die Mädchen und die Jungen</td>
    </tr>
    <tr>
        <td>The girls are children</td>
        <td>Die Mädchen sind Kinder</td>
    </tr>
    <tr>
        <td>Ducks are birds</td>
        <td>Enten sind Vögel</td>
    </tr>
    <tr>
        <td>These girls are eating bread</td>
        <td>Die Mädchen essen Brot</td>
    </tr>
    <tr>
        <td>She and I are eating apples</td>
        <td>Sie und Ich essen Äpfel</td>
    </tr>
    <tr>
        <td>The woman and the girl are eating apples</td>
        <td>Die Frau und das Mädchen essen Äpfel</td>
    </tr>
</table>
