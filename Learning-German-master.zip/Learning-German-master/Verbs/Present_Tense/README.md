# Verbs

### Present Tense - 1

<table>
    <tr>
        <th>English</th>
        <th>German</th>
    </tr>
    <tr>
        <td>We like wine</td>
        <td>Wir mögen Wein</td>
    </tr>
    <tr>
        <td>Are you learning German?</td>
        <td>Lernst du Deutsch?</td>
    </tr>
    <tr>
        <td>We are reading newspaper</td>
        <td>Wir lesen Zeitungen</td>
    </tr>
    <tr>
        <td>You write</td>
        <td>Du schreibst</td>
    </tr>
    <tr>
        <td>I see people</td>
        <td>Ich sehe Menschen</td>
    </tr>
    <tr>
        <td>I am reading the newspaper</td>
        <td>Ich lese die Zeitung</td>
    </tr>
    <tr>
        <td>I am hearing a animal</td>
        <td>Ich höre ein Tier</td>
    </tr>
    <tr>
        <td>The boy is learning German</td>
        <td>Der Junge lernt Deutsch</td>
    </tr>
    <tr>
        <td>I like the apple</td>
        <td>Ich mag den Apfel</td>
    </tr>
    <tr>
        <td>I learn</td>
        <td>Ich lerne</td>
    </tr>
    <tr>
        <td>We are writing</td>
        <td>Wir schreiben</td>
    </tr>
    <tr>
        <td>The boy is reading a newspaper</td>
        <td>Der Junge liest eine Zeitung</td>
    </tr>
    <tr>
        <td></td>
        <td></td>
    </tr>
</table>

### Present Tense - 2

<table>
    <tr>
        <th>English</th>
        <th>German</th>
    </tr>
    <tr>
        <td>I am swimming and she is swimming</td>
        <td>Ich schwimme und sie schwimmt</td>
    </tr>
    <tr>
        <td>We are running</td>
        <td>Wir rennen</td>
    </tr>
    <tr>
        <td>He is swimming</td>
        <td>Er schwimmt</td>
    </tr>
    <tr>
        <td>I am bringing the rice</td>
        <td>Ich bringe den Reis</td>
    </tr>
    <tr>
        <td>I am driving</td>
        <td>Ich fahre</td>
    </tr>
    <tr>
        <td>I deliver milk</td>
        <td>Ich liefere Milch</td>
    </tr>
    <tr>
        <td>You are thinking</td>
        <td>Du denkst</td>
    </tr>
    <tr>
        <td>He knows the beer</td>
        <td>Er kennt das Bier</td>
    </tr>
    <tr>
        <td>I am thinking</td>
        <td>Ich denke</td>
    </tr>
    <tr>
        <td>A fish and a dog are swimming</td>
        <td>Ein Fisch und ein schwimmen</td>
    </tr>
    <tr>
        <td>You are swimming</td>
        <td>Du schwimmst</td>
    </tr>
    <tr>
        <td>She is thinking</td>
        <td>Sie denkt</td>
    </tr>
    <tr>
        <td>He is running</td>
        <td>Er rennt</td>
    </tr>
    <tr>
        <td>She is driving slowly</td>
        <td>Sie fährt langsam</td>
    </tr>
    <tr>
        <td>She is running</td>
        <td>Sie rennt</td>
    </tr>
</table>

### Present Tense - 3

<table>
    <tr>
        <th>English</th>
        <th>German</th>
    </tr>
    <tr>
        <td>He is playing</td>
        <td>Er spielt</td>
    </tr>
    <tr>
        <td>He is walking quickly</td>
        <td>Er geht schnell</td>
    </tr>
    <tr>
        <td>I am making tea</td>
        <td>Ich mache Tee</td>
    </tr>
    <tr>
        <td>I am not walking</td>
        <td>Ich laufe night</td>
    </tr>
    <tr>
        <td>I am sleeping</td>
        <td>Ich schlefe</td>
    </tr>
    <tr>
        <td>He wants an apple</td>
        <td>Er will einen Apfel</td>
    </tr>
    <tr>
        <td>She and I are going</td>
        <td>Sie und ich gehen</td>
    </tr>
    <tr>
        <td>The ducks are playing</td>
        <td>Die Enten spielen</td>
    </tr>
    <tr>
        <td>I am sleeping</td>
        <td>Ich schlafe</td>
    </tr>
    <tr>
        <td>He is sleeping</td>
        <td>Er  schläft</td>
    </tr>
    <tr>
        <td>You are playing</td>
        <td>Du spielst</td>
    </tr>
    <tr>
        <td>I am walking slowly</td>
        <td>Ich gehe langsum</td>
    </tr>
    <tr>
        <td>You and i are playing</td>
        <td>Du und ich spielen</td>
    </tr>
    <tr>
        <td>I go</td>
        <td>Ich gehe</td>
    </tr>
    <tr>
        <td>She and I are going</td>
        <td>Sie und ein gehe</td>
    </tr>
</table>

### Present Tense - 4

<table>
    <tr>
        <th>English</th>
        <th>German</th>
    </tr>
    <tr>
        <td>Wir brauchen Duolingo</td>
        <td>We need duolingo</td>
    </tr>
    <tr>
        <td>We are drinking, and you are paying</td>
        <td>Wir trinken , und du bezahlst</td>
    </tr>
    <tr>
        <td>You are beginning</td>
        <td>Du beginnst</td>
    </tr>
    <tr>
        <td>He is washing the dog</td>
        <td>Er wäscht den Hund</td>
    </tr>
    <tr>
        <td>He is paying</td>
        <td>Er bezahlt</td>
    </tr>
    <tr>
        <td>No, i am paying</td>
        <td>Nein, ich bezahle</td>
    </tr>
    <tr>
        <td>I need water</td>
        <td>Ich brauche Wasser</td>
    </tr>
    <tr>
        <td>We are beginning</td>
        <td>Wir beginnen</td>
    </tr>
    <tr>
        <td>We are paying nothing</td>
        <td>Wir bezahlen nicht</td>
    </tr>
    <tr>
        <td>We are washing the tomatoes</td>
        <td>Wir waschen die Tomaten</td>
    </tr>
</table>
