# Negative and Positive Statements

<table>
    <tr>
        <th>English</th>
        <th>German</th>
    </tr>
    <tr>
        <td>The apple is not normal</td>
        <td>Der Apfel ist nicht normal</td>
    </tr>
    <tr>
        <td>I am Sad</td>
        <td>Ich bin traurig</td>
    </tr>
    <tr>
        <td>The boy is funny</td>
        <td>The junge ist lustig</td>
    </tr>
    <tr>
        <td>It is easy</td>
        <td>Es ist einfach</td>
    </tr>
    <tr>
        <td>I am finished</td>
        <td>Ich bin fertig</td>
    </tr>
    <tr>
        <td>I am not from India</td>
        <td>Ich bin nicht aus Indien</td>
    </tr>
    <tr>
        <td>It is easy</td>
        <td>Es ist einfach</td>
    </tr>
    <tr>
        <td>I am not finished</td>
        <td>Ich bin nicht fertig</td>
    </tr>
    </tr>
        <td>It is not funny</td>
        <td>Es ist nicht lustig</td>
    </tr>
    <tr>
        <td>I am sad</td>
        <td>Ich bin traurig</td>
    </tr>
    <tr>
        <td>I am healthy</td>
        <td>Ich bin gesund</td>
    </tr>
</table>
