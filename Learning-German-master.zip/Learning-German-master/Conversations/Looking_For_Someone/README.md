# Conversations: Looking For Someone

### Boy looking for a Girl (Sarah) :
<table>
	<tr>
        <th>English</th>
        <th>German</th>
    </tr>
    <tr>
        <td>Excuse me, is Sarah here?</td>
        <td>Entschuldigung, ist Sarah da?</td>
    </tr>
    <tr>
        <td>Yes, she's here</td>
        <td>Ja, sie ist hier</td>
    </tr>
    <tr>
        <td>She's out</td>
        <td>Sie ist fort</td>
    </tr>
    <tr>
        <td>Do you know where I could find her?</td>
        <td>Wissen Sie wo ich sie finden kann?</td>
    </tr>
    <tr>
        <td>You can call her on her mobile phone</td>
        <td>Sie können sie über ihr Handy erreichen</td>
    </tr>
    <tr>
        <td>She is at work</td>
        <td>Sie ist auf ihrer Arbeit</td>
    </tr>
    <tr>
        <td>She is at home</td>
        <td>Sie ist zuhause</td>
    </tr>
</table>

### Girl looking for a Boy (Julian) :
<table>
    <tr>
        <th>English</th>
        <th>German</th>
    </tr>
    <tr>
        <td>Excuse me, is Julien here?</td>
        <td>Entschuldigung, ist Julian da?</td>
    </tr>
    <tr>
        <td>Yes, he's here</td>
        <td>Ja, er ist hier</td>
    </tr>
    <tr>
        <td>He's out</td>
        <td>Er ist fort</td>
    </tr>
    <tr>
        <td>Do you know where I could find him?</td>
        <td>Wissen Sie wo ich ihn finden kann? </td>
    </tr>
    <tr>
        <td>You can call him on his mobile phone</td>
        <td>Sie können ihn über sein Handy erreichen</td>
    </tr>
    <tr>
        <td>He is at work</td>
        <td>Er ist auf seiner Arbeit</td>
    </tr>
    <tr>
        <td>He is at home</td>
        <td>Er ist zuhause</td>
    </tr>
</table>
