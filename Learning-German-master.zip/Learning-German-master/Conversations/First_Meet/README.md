# Conversations

### Simple German Language conversation :
### First Meet

<table>
	<tr>
        <th>English</th>
        <th>German</th>
    </tr>
    <tr>
        <td>Hello. How are you?</td>
        <td>Hallo, wie geht es dir?</td>
    </tr>
    <tr>
        <td>Hello. I'm fine, thank you</td>
        <td>Hallo, gut danke</td>
    </tr>
    <tr>
        <td>Do you speak German?</td>
        <td>Sprichst du Deutsch?</td>
    </tr>
    <tr>
        <td>No, I don't speak German</td>
        <td>Nein, ich spreche kein Deutsch</td>
    </tr>
    <tr>
        <td>Only a little bit</td>
        <td>Nur ein wenig</td>
    </tr>
    <tr>
        <td>Where do you come from?</td>
        <td>Woher kommst du?</td>
    </tr>
    <tr>
        <td>What is your nationality?</td>
        <td>Was ist deine Staatsbürgerschaft?</td>
    </tr>
    <tr>
        <td>I am English (Man Speaks)</td>
        <td>Ich bin Engländer</td>
    </tr>
    <tr>
        <td>I am English (Woman Speaks)</td>
        <td>Ich bin Engländerin</td>
    </tr>
    <tr>
        <td>And you, do you live here?</td>
        <td>Und du, lebst du hier?</td>
    </tr>
    <tr>
        <td>Yes, I live here</td>
        <td>Ja, ich wohne hier</td>
    </tr>
    <tr>
        <td>My name is Sarah, what's your name?</td>
        <td>Mein Name ist Sarah. Und du, wie heißt du?</td>
    </tr>
    <tr>
        <td>What are you doing here?</td>
        <td>Was machst du hier?</td>
    </tr>
    <tr>
        <td>I am on holiday</td>
        <td>Ich bin auf Urlaub</td>
    </tr>
    <tr>
        <td>We are on holiday</td>
        <td>Wir sind auf Urlaub</td>
    </tr>
    <tr>
        <td>I am on a business trip</td>
        <td>Ich bin auf Geschäftsreise</td>
    </tr>
    <tr>
        <td>I work here</td>
        <td>Ich arbeite hier</td>
    </tr>
    <tr>
        <td>We work here</td>
        <td>Wir arbeiten hier</td>
    </tr>
    <tr>
        <td>Where are the good places to go out and eat?</td>
        <td>Was sind die guten Lokale um auszugehen und zu essen?</td>
    </tr>
    <tr>
        <td>Is there a museum in the neighbourhood?</td>
        <td>Gibt es ein Museum in der Gegend?</td>
    </tr>
    <tr>
        <td>Where could I get an internet connection?</td>
        <td>Wo finde ich eine Internetverbindung?</td>
    </tr>
</table>
