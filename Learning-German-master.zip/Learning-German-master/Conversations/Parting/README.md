# Conversations: 

## Parting
<table>
	<tr>
        <th>English</th>
        <th>German</th>
    </tr>
    <tr>
        <td>It's late, I have to go!</td>
        <td>Es ist spät! Ich muß los!</td>
    </tr>
    <tr>
        <td>Could we meet again?</td>
        <td>Könnten wir uns wiedersehen?</td>
    </tr>
    <tr>
        <td>Yes with pleasure</td>
        <td>Ja, mit Vergnügen</td>
    </tr>
    <tr>
        <td>This is my address</td>
        <td>Das ist meine Adresse</td>
    </tr>
    <tr>
        <td>Do you have a phone number?</td>
        <td>Hast du eine Telefonnummer?</td>
    </tr>
    <tr>
        <td>Yes, here it is</td>
        <td>Ja, hier ist sie</td>
    </tr>
    <tr>
        <td>I spent a nice moment with you</td>
        <td>Ich habe einen schönen Moment mit Dir verbracht</td>
    </tr>
    <tr>
        <td>Me too, it was a nice to meet you</td>
        <td>Ich auch. Es war schön Dich kennenzulernen</td>
    </tr>
    <tr>
        <td>We will see each other soon</td>
        <td>Wir sehen uns dann bald</td>
    </tr>
    <tr>
        <td>I hope so too</td>
        <td>Ich hoffe es auch</td>
    </tr>
    <tr>
        <td>Goodbye</td>
        <td>Auf Wiedersehen</td>
    </tr>
    <tr>
        <td>See you tomorrow</td>
        <td>Bis morgen</td>
    </tr>
    <tr>
        <td>Bye!</td>
        <td>Tschüß!</td>
    </tr>
</table>
