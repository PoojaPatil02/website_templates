# Conversations

### Simple German Language conversation :
### The Restaurant

<table>
	<tr>
        <th>English</th>
        <th>German</th>
    </tr>
    <tr>
        <td>The restaurant</td>
        <td>Das Restaurant</td>
    </tr>
    <tr>
        <td>Do you want to eat something ?</td>
        <td>Willst du etwas essen ?</td>
    </tr>
    <tr>
        <td>Yes I would like to</td>
        <td>Ja, ich möchte gerne</td>
    </tr>
    <tr>
        <td>Eat</td>
        <td>Essen</td>
    </tr>
    <tr>
        <td>Where can we go for a meal?</td>
        <td>Wo können wir essen gehen?</td>
    </tr>
    <tr>
        <td>Where can we have lunch?</td>
        <td>Wo können wir mittagessen?</td>
    </tr>
    <tr>
        <td>Dinner</td>
        <td>Abendessen</td>
    </tr>
    <tr>
        <td>Breakfast</td>
        <td>Frühstück</td>
    </tr>
    <tr>
        <td>Entschuldigen Sie mich!</td>
        <td>Excuse me!</td>
    </tr>
    <tr>
        <td>The menu, please</td>
        <td>Die Karte bitte</td>
    </tr>
    <tr>
        <td>Here is the menu</td>
        <td>Hier ist die Karte</td>
    </tr>
    <tr>
        <td>What do you prefer to eat? Meat or fish?</td>
        <td>Was ißt du lieber, Fleisch oder Fisch?</td>
    </tr>
    <tr>
        <td>With rice</td>
        <td>Mit Reis</td>
    </tr>
    <tr>
        <td>With noodles</td>
        <td>Mit Nudeln</td>
    </tr>
    <tr>
        <td>Potatoes</td>
        <td>Kartoffeln</td>
    </tr>
    <tr>
        <td>Vegetables</td>
        <td>Gemüse</td>
    </tr>
    <tr>
        <td>Scrambled eggs</td>
        <td>Rührei</td>
    </tr>
    <tr>
        <td>Fried eggs</td>
        <td>Spiegelei</td>
    </tr>
    <tr>
        <td>Boiled egg</td>
        <td>Gekochtes Ei</td>
    </tr>
    <tr>
        <td>Bread</td>
        <td>Brot</td>
    </tr>
    <tr>
        <td>Butter</td>
        <td>Butter</td>
    </tr>
    <tr>
        <td>Salad</td>
        <td>Salat</td>
    </tr>
    <tr>
        <td>Soup</td>
        <td>Suppe</td>
    </tr>
    <tr>
        <td>Dessert</td>
        <td>Nachtisch</td>
    </tr>
    <tr>
        <td>Fruit</td>
        <td>Früchte</td>
    </tr>
    <tr>
        <td>Can I have a knife, please?</td>
        <td>Könnte ich bitte ein Messer haben?</td>
    </tr>
    <tr>
        <td>Yes, I'll bring it to you right away</td>
        <td>Ja, ich bringe es Ihnen sofort</td>
    </tr>
    <tr>
        <td>Knife</td>
        <td>Messer</td>
    </tr>
    <tr>
        <td>Fork</td>
        <td>Gabel</td>
    </tr>
    <tr>
        <td>Spoon</td>
        <td>Löffel</td>
    </tr>
    <tr>
        <td>Is it a warm dish?</td>
        <td>Ist es ein warmes Gericht?</td>
    </tr>
    <tr>
        <td>Yes, very hot also!</td>
        <td>Ja und auch sehr scharf!</td>
    </tr>
    <tr>
        <td>Warm</td>
        <td>Warm</td>
    </tr>
    <tr>
        <td>Cold</td>
        <td>Kalt</td>
    </tr>
    <tr>
        <td>Hot</td>
        <td>Scharf</td>
    </tr>
    <tr>
        <td>I'll have fish</td>
        <td>Ich werde Fisch nehmen!</td>
    </tr>
    <tr>
        <td>Me too</td>
        <td>Ich auch</td>
    </tr>
</table>
