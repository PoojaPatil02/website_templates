# Conversations

### Simple German Language conversation :
### The Bar

<table>
	<tr>
        <th>English</th>
        <th>German</th>
    </tr>
    <tr>
        <td>The bar</td>
        <td>Die Bar</td>
    </tr>
    <tr>
        <td>Would you like to have a drink?</td>
        <td>Willst du etwas trinken?</td>
    </tr>
    <tr>
        <td>To drink</td>
        <td>Trinken</td>
    </tr>
    <tr>
        <td>Glass</td>
        <td>Glas</td>
    </tr>
    <tr>
        <td>With pleasure</td>
        <td>Gerne</td>
    </tr>
    <tr>
        <td>What would you like?</td>
        <td>Was möchtest du gerne?</td>
    </tr>
    <tr>
        <td>What's on offer?</td>
        <td>Was gibt es zu trinken?</td>
    </tr>
    <tr>
        <td>Water or fruit juices</td>
        <td>Wasser oder Fruchtsäfte</td>
    </tr>
    <tr>
        <td>Water</td>
        <td>Wasser</td>
    </tr>
    <tr>
        <td>Can you add some ice cubes, please?</td>
        <td>Können Sie bitte Eiswürfel dazugeben?</td>
    </tr>
    <tr>
        <td>Ice cubes</td>
        <td>Eiswürfel</td>
    </tr>
    <tr>
        <td>Hot Chocolate</td>
        <td>Heiße Schokolade</td>
    </tr>
    <tr>
        <td>Milk</td>
        <td>Milch</td>
    </tr>
    <tr>
        <td>Tea</td>
        <td>Tee</td>
    </tr>
    <tr>
        <td>Coffee</td>
        <td>Kaffee</td>
    </tr>
    <tr>
        <td>With sugar</td>
        <td>Mit Zucker</td>
    </tr>
    <tr>
        <td>With cream</td>
        <td>Mit Sahne</td>
    </tr>
    <tr>
        <td>Wine</td>
        <td>Wein</td>
    </tr>
    <tr>
        <td>Beer</td>
        <td>Bier</td>
    </tr>
    <tr>
        <td>A tea please</td>
        <td>Einen Tee bitte!</td>
    </tr>
    <tr>
        <td>Two teas please!</td>
        <td>Zwei Tee bitte!</td>
    </tr>
    <tr>
        <td>A beer please</td>
        <td>Ein Bier bitte</td>
    </tr>
    <tr>
        <td>Two beers please!</td>
        <td>Zwei Bier bitte</td>
    </tr>
    <tr>
        <td>What would you like to drink?</td>
        <td>Was wollen Sie trinken?</td>
    </tr>
    <tr>
        <td>Nothing, thanks</td>
        <td>Nichts, danke</td>
    </tr>
    <tr>
        <td>Cheers!</td>
        <td>Prost!</td>
    </tr>
    <tr>
        <td>Cheers!</td>
        <td>Zum Wohle!</td>
    </tr>
    <tr>
        <td>Pay please!</td>
        <td>Zahlen bitte!</td>
    </tr>
    <tr>
        <td>How much is it?</td>
        <td>Wieviel macht das?</td>
    </tr>
    <tr>
        <td>Twenty euros</td>
        <td>Zwanzig Euro</td>
    </tr>
    <tr>
        <td>It's on me</td>
        <td>Das geht auf mich / Das geht auf meine Rechnung</td>
    </tr>
</table>
