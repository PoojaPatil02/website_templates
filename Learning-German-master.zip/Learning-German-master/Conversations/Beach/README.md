# Conversations

### Simple German Language conversation :
### The Beach

<table>
	<tr>
        <th>English</th>
        <th>German</th>
    </tr>
    <tr>
        <td>The beach</td>
        <td>Der Strand</td>
    </tr>
    <tr>
        <td>Do you know where I can buy a ball?</td>
        <td>Wissen Sie wo ich einen Ball kaufen kann?</td>
    </tr>
    <tr>
        <td>There is a store in this direction</td>
        <td>Es gibt ein Geschäft in dieser Richtung</td>
    </tr>
    <tr>
        <td>a ball</td>
        <td>Ein Ball</td>
    </tr>
    <tr>
        <td>Binoculars</td>
        <td>Ein Fernglas</td>
    </tr>
    <tr>
        <td>a cap</td>
        <td>Eine Kappe</td>
    </tr>
    <tr>
        <td>a towel</td>
        <td>Ein Badetuch</td>
    </tr>
    <tr>
        <td>Sandals</td>
        <td>Sandalen</td>
    </tr>
    <tr>
        <td>a bucket</td>
        <td>Ein Eimer</td>
    </tr>
    <tr>
        <td>Suntan lotion</td>
        <td>Eine Sonnencreme</td>
    </tr>
    <tr>
        <td>Swimming trunks</td>
        <td>Eine Badehose</td>
    </tr>
    <tr>
        <td>Sunglasses</td>
        <td>Eine Sonnenbrille</td>
    </tr>
    <tr>
        <td>Shellfish</td>
        <td>Schalentiere</td>
    </tr>
    <tr>
        <td>Sunbathing</td>
        <td>Sich sonnen</td>
    </tr>
    <tr>
        <td>Sunny</td>
        <td>Sonnig</td>
    </tr>
    <tr>
        <td>Sunset</td>
        <td>Der Sonnenuntergang</td>
    </tr>
    <tr>
        <td>Parasol</td>
        <td>Der Sonnenschirm</td>
    </tr>
    <tr>
        <td>Sunshine</td>
        <td>Die Sonne</td>
    </tr>
    <tr>
        <td>Sunstroke</td>
        <td>Ein Sonnenstich</td>
    </tr>
    <tr>
        <td>Is it dangerous to swim here?</td>
        <td>Ist es gefährlich hier zu schwimmen?</td>
    </tr>
    <tr>
        <td>No, it is not dangerous</td>
        <td>Nein, es ist nicht gefährlich</td>
    </tr>
    <tr>
        <td>Yes, it is forbidden to swim here</td>
        <td>Ja, es ist untersagt hier zu schwimmen</td>
    </tr>
    <tr>
        <td>Swim</td>
        <td>Schwimmen</td>
    </tr>
    <tr>
        <td>Swimming</td>
        <td>Das Schwimmen</td>
    </tr>
    <tr>
        <td>Wave</td>
        <td>Die Welle</td>
    </tr>
    <tr>
        <td>Sea</td>
        <td>Das Meer</td>
    </tr>
    <tr>
        <td>Dune</td>
        <td>Die Düne</td>
    </tr>
    <tr>
        <td>Sand</td>
        <td>Der Sand</td>
    </tr>
    <tr>
        <td>What is the weather forecast for tomorrow?</td>
        <td>Was ist die Wettervorhersage für morgen?</td>
    </tr>
    <tr>
        <td>The weather is going to change</td>
        <td>Das Wetter wird sich ändern</td>
    </tr>
    <tr>
        <td>It is going to rain</td>
        <td>Es wird regnen</td>
    </tr>
    <tr>
        <td>It will be sunny</td>
        <td>Es wird sonnig</td>
    </tr>
    <tr>
        <td>It will be very windy</td>
        <td>Es wird sehr windig</td>
    </tr>
    <tr>
        <td>Swimming suit</td>
        <td>Der Badeanzug</td>
    </tr>
</table>
