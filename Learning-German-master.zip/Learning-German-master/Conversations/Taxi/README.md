# Conversations

### Simple German Language conversation :
### Taxi

<table>
	<tr>
        <th>English</th>
        <th>German</th>
    </tr>
    <tr>
        <td>Taxi!</td>
        <td>Taxi!</td>
    </tr>
    <tr>
        <td>Where would you like to go?</td>
        <td>Wo möchten Sie denn hin?</td>
    </tr>
    <tr>
        <td>I'm going to the train station</td>
        <td>Ich muß zum Bahnhof</td>
    </tr>
    <tr>
        <td>I'm going to the Day and Night Hotel</td>
        <td>Ich muß ins Hotel Tag und Nacht</td>
    </tr>
    <tr>
        <td>Can you take me to the airport, please?</td>
        <td>Können Sie mich zum Flughafen bringen, bitte?</td>
    </tr>
    <tr>
        <td>Can you take my luggage?</td>
        <td>Können Sie mein Gepäck nehmen?</td>
    </tr>
    <tr>
        <td>Is that far from here?</td>
        <td>Ist das weit von hier entfernt?</td>
    </tr>
    <tr>
        <td>No, it is very close</td>
        <td>Nein, es ist ganz nah</td>
    </tr>
    <tr>
        <td>Yes it's a little bit further away</td>
        <td>Das ist ein bisschen weiter weg</td>
    </tr>
    <tr>
        <td>How much will that cost?</td>
        <td>Wieviel wird das kosten?</td>
    </tr>
    <tr>
        <td>Take me there, please</td>
        <td>Fahren Sie mich hin bitte</td>
    </tr>
    <tr>
        <td>You go right</td>
        <td>Das ist rechts</td>
    </tr>
    <tr>
        <td>You go left</td>
        <td>Das ist links</td>
    </tr>
    <tr>
        <td>It's straight on</td>
        <td>Das ist gerade aus</td>
    </tr>
    <tr>
        <td>It's right here</td>
        <td>Das ist hier</td>
    </tr>
    <tr>
        <td>It's that way</td>
        <td>Dort</td>
    </tr>
    <tr>
        <td>Stop!</td>
        <td>Stop!</td>
    </tr>
    <tr>
        <td>Take your time</td>
        <td>Nehmen Sie sich Zeit</td>
    </tr>
    <tr>
        <td>Can I have a receipt, please?</td>
        <td>Könnte ich eine Rechnung bekommen?</td>
    </tr>
</table>
