# Conversations

### Simple German Language conversation :
### Family

<table>
	<tr>
        <th>English</th>
        <th>German</th>
    </tr>
    <tr>
        <td>Family</td>
        <td>Familie</td>
    </tr>
    <tr>
        <td>Do you have a family here?</td>
        <td>Hast du Familie hier?</td>
    </tr>
    <tr>
        <td>My father</td>
        <td>Mein Vater</td>
    </tr>
    <tr>
        <td>My mother</td>
        <td>Meine Mutter</td>
    </tr>
    <tr>
        <td>My son</td>
        <td>Mein Sohn</td>
    </tr>
    <tr>
        <td>My daughter</td>
        <td>Meine Tochter </td>
    </tr>
    <tr>
        <td>A brother</td>
        <td>Ein Bruder</td>
    </tr>
    <tr>
        <td>A sister</td>
        <td>Eine Schwester</td>
    </tr>
    <tr>
        <td>A friend (Male)</td>
        <td>Ein Freund</td>
    </tr>
    <tr>
        <td>A friend (Female)</td>
        <td>Eine Freundin</td>
    </tr>
    <tr>
        <td>My boyfriend</td>
        <td>Mein Freund</td>
    </tr>
    <tr>
        <td>My girlfriend</td>
        <td>Meine Freundin</td>
    </tr>
    <tr>
        <td>My husband</td>
        <td>Mein Ehemann</td>
    </tr>
    <tr>
        <td>My wife</td>
        <td>Meine Ehefrau</td>
    </tr>
</table>
