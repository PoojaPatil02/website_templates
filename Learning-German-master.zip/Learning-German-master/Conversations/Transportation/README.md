# Conversations

### Simple German Language conversation :
### Transportation

<table>
	<tr>
        <th>English</th>
        <th>German</th>
    </tr>
    <tr>
        <td>Excuse me! I'm looking for the bus stop</td>
        <td>Verzeihung! Ich suche die Bushaltestelle</td>
    </tr>
    <tr>
        <td>How much is a ticket to Sun City?</td>
        <td>Was kostet eine Fahrkarte nach Sonnenstadt?</td>
    </tr>
    <tr>
        <td>Where does this train go, please?</td>
        <td>Wohin fährt dieser Zug? </td>
    </tr>
    <tr>
        <td>Does this train stop at Sun City?</td>
        <td>Hält dieser Zug in Sonnenstadt an?</td>
    </tr>
    <tr>
        <td>When does the train for Sun City leave? </td>
        <td>Wann fährt der Zug nach Sonnenstadt los? </td>
    </tr>
    <tr>
        <td>When will this train arrive in Sun City?</td>
        <td>Wann kommt dieser Zug in Sonnenstadt an?</td>
    </tr>
    <tr>
        <td>A ticket for Sun City, please</td>
        <td>Eine Fahrkarte nach Sonnenstadt bitte</td>
    </tr>
    <tr>
        <td>Do you have the train's time table?</td>
        <td>Haben Sie den Fahrplan des Zuges?</td>
    </tr>
    <tr>
        <td>Bus schedule</td>
        <td>Bus Fahrplan</td>
    </tr>
    <tr>
        <td>Excuse me, which train goes to Sun City?</td>
        <td>Entschuldigung, welcher Zug fährt nach Sonnenstadt?</td>
    </tr>
    <tr>
        <td>This one</td>
        <td>Es ist dieser</td>
    </tr>
    <tr>
        <td>Thanks</td>
        <td>Danke schön!</td>
    </tr>
    <tr>
        <td>Don't mention it, have a good trip!</td>
        <td>Gern geschehen, gute Fahrt!</td>
    </tr>
    <tr>
        <td>The garage</td>
        <td>Die Werkstatt</td>
    </tr>
    <tr>
        <td>The petrol station</td>
        <td>Die Tankstelle</td>
    </tr>
    <tr>
        <td>A full tank, please</td>
        <td>Volltanken, bitte</td>
    </tr>
    <tr>
        <td>Bike</td>
        <td>Fahrrad</td>
    </tr>
    <tr>
        <td>Town centre</td>
        <td>Stadtzentrum</td>
    </tr>
     <tr>
        <td>Suburb</td>
        <td>Vorstadt</td>
    </tr>
     <tr>
        <td>It is a city</td>
        <td>Es ist eine Stadt</td>
    </tr>
     <tr>
        <td>It is a village</td>
        <td>Es ist ein Dorf</td>
    </tr>
     <tr>
        <td>A mountain</td>
        <td>Ein Berg</td>
    </tr>
     <tr>
        <td>a lake</td>
        <td>Ein See</td>
    </tr>
     <tr>
        <td>The countryside</td>
        <td>Am Land</td>
    </tr>
</table>
