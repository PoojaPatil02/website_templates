# Questions and Statements

### PART 1

<table>
    <tr>
        <th>English</th>
        <th>German</th>
    </tr>
    <tr>
        <td>He is handsome</td>
        <td>Er ist schön</td>
    </tr>
    <tr>
        <td>You are important</td>
        <td>Du bist wichtig</td>
    </tr>
    <tr>
        <td>That is new</td>
        <td>Das ist neu</td>
    </tr>
    <tr>
        <td>That food is expensive</td>
        <td>Das Essen ist teuer</td>
    </tr>
    <tr>
        <td>You are speaking quickly</td>
        <td>Du sprichst schnell</td>
    </tr>
    <tr>
        <td>You are slow</td>
        <td>Du bist langsam</td>
    </tr>
    <tr>
        <td>Yes, it is far</td>
        <td>Ja, es ist weit</td>
    </tr>
    <tr>
        <td>He is fast</td>
        <td>Er ist schnell</td>
    </tr>
    <tr>
        <td>Yes, she is beautiful</td>
        <td>Ja, sie ist schön</td>
    </tr>
    <tr>
        <td>Is he slow?</td>
        <td>Er ist langsam</td>
    </tr>
    <tr>
        <td>That is important</td>
        <td>Das ist wichtig</td>
    </tr>
</table>

### PART 2

<table>
    <tr>
        <th>English</th>
        <th>German</th>
    </tr>
    <tr>
        <td>Is this fly heavy?</td>
        <td>Ist die Fliege schwer?</td>
    </tr>
    <tr>
        <td>Yes, that is correct</td>
        <td>Ja, das ist richtig</td>
    </tr>
    <tr>
        <td>Are the men tired?</td>
        <td>Sind die Männer müde?</td>
    </tr>
    <tr>
        <td>Are you young?</td>
        <td>Bist du jung?</td>
    </tr>
    <tr>
        <td>Is the dog old?</td>
        <td>Ist der Hund alt?</td>
    </tr>
    <tr>
        <td>It is cold</td>
        <td>Es ist kalt</td>
    </tr>
    <tr>
        <td>David and Max, are you tired?</td>
        <td>David und Max, seid ihr müde?</td>
    </tr>
    <tr>
        <td>Is that right?</td>
        <td>Ist das richtig?</td>
    </tr>
    <tr>
        <td>Is the man young?</td>
        <td>Ist der Mann jung?</td>
    </tr>
    <tr>
        <td>Is the woman old?</td>
        <td>Ist die Frau alt?</td>
    </tr>
</table>

### PART 3

<table>
    <tr>
        <th>English</th>
        <th>German</th>
    </tr>
    <tr>
        <td>Is it warm?</td>
        <td>Ist es warm?</td>
    </tr>
    <tr>
        <td>It is dirty </td>
        <td>Es ist dreckig</td>
    </tr>
    <tr>
        <td>It is deep</td>
        <td>Es ist tief</td>
    </tr>
    <tr>
        <td>It is tall</td>
        <td>Es ist hoch</td>
    </tr>
    <tr>
        <td>Is the water clean?</td>
         <td>Ist das Wasser sauber?</td>
    </tr>
    <tr>
        <td>Is the water dirty?</td>
        <td>Ist das Wasser schmutzig?</td>
    </tr>
</table>