# Useful books
* [German.pdf](https://github.com/DipanshKhandelwal/Learning-German/blob/master/Book/German.pdf)
* [German_Essential_Grammar.pdf](https://github.com/DipanshKhandelwal/Learning-German/blob/master/Book/German_Essential_Grammar.pdf)
* [Intermediate german.pdf](https://github.com/DipanshKhandelwal/Learning-German/blob/master/Book/Intermediate%20german.pdf)
